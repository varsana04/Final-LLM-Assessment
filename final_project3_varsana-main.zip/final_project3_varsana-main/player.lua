Player = {}

local PlayerState = {
    DEFAULT_MANA = 1,
    INITIAL_BONUS_MANA = 0,
    INITIAL_POINTS = 0,
    MIN_POWER = 1
}

local function createPlayerData(deck)
    return {
        deck = deck or {},
        hand = {},
        discard = {},
        mana = PlayerState.DEFAULT_MANA,
        bonusMana = PlayerState.INITIAL_BONUS_MANA,
        points = PlayerState.INITIAL_POINTS,
        submitted = false
    }
end

local function notifyCardDrawn(playerData, card)
    Observer.notify("cardDrawn", {
        player = playerData,
        card = card,
        handSize = #playerData.hand
    })
end

local function notifyManaSpent(playerData, amount)
    Observer.notify("manaSpent", {
        player = playerData,
        amount = amount,
        remainingMana = playerData.mana
    })
end

local function notifyPointsAdded(playerData, amount)
    Observer.notify("pointsAdded", {
        player = playerData,
        amount = amount,
        totalPoints = playerData.points
    })
end

local function notifyPlayerSubmitted(playerData)
    Observer.notify("playerSubmitted", {
        player = playerData,
        submitted = true
    })
end

function Player.new(deck)
    return createPlayerData(deck)
end

function Player.drawCard(playerData)
    if #playerData.deck > 0 and #playerData.hand < Game.HAND_SIZE then
        local card = table.remove(playerData.deck, 1)
        table.insert(playerData.hand, card)
        notifyCardDrawn(playerData, card)
        return card
    end
    return nil
end

function Player.removeFromHand(playerData, cardToRemove)
    for i, card in ipairs(playerData.hand) do
        if card == cardToRemove then
            table.remove(playerData.hand, i)
            return true
        end
    end
    return false
end

function Player.getMana(playerData)
    return playerData.mana
end

function Player.spendMana(playerData, amount)
    if playerData.mana >= amount then
        playerData.mana = playerData.mana - amount
        notifyManaSpent(playerData, amount)
        return true
    end
    return false
end

function Player.addBonusMana(playerData, amount)
    playerData.bonusMana = playerData.bonusMana + (amount or 1)
end

function Player.resetMana(playerData, turn)
    playerData.mana = turn + playerData.bonusMana
    playerData.bonusMana = PlayerState.INITIAL_BONUS_MANA
end

function Player.addPoints(playerData, amount)
    playerData.points = playerData.points + amount
    notifyPointsAdded(playerData, amount)
end

function Player.getPoints(playerData)
    return playerData.points
end

function Player.resetPoints(playerData)
    playerData.points = PlayerState.INITIAL_POINTS
end

function Player.getHandSize(playerData)
    return #playerData.hand
end

function Player.getHandCard(playerData, index)
    return playerData.hand[index]
end

function Player.hasPlayableCards(playerData)
    for _, card in ipairs(playerData.hand) do
        if card.cost <= playerData.mana then
            return true
        end
    end
    return false
end

function Player.getPlayableCards(playerData)
    local playableCards = {}
    for _, card in ipairs(playerData.hand) do
        if card.cost <= playerData.mana then
            table.insert(playableCards, card)
        end
    end
    return playableCards
end

function Player.getDeckSize(playerData)
    return #playerData.deck
end

function Player.shuffleDeck(playerData)
    local deck = playerData.deck
    for i = #deck, 2, -1 do
        local j = math.random(i)
        deck[i], deck[j] = deck[j], deck[i]
    end
end

function Player.addToDeck(playerData, card)
    table.insert(playerData.deck, card)
end

function Player.addToDiscard(playerData, card)
    table.insert(playerData.discard, card)
end

function Player.getDiscardSize(playerData)
    return #playerData.discard
end

function Player.clearDiscard(playerData)
    playerData.discard = {}
end

function Player.submit(playerData)
    playerData.submitted = true
    notifyPlayerSubmitted(playerData)
end

function Player.resetSubmission(playerData)
    playerData.submitted = false
end

function Player.hasSubmitted(playerData)
    return playerData.submitted
end

function Player.startTurn(playerData, turn)
    Player.resetMana(playerData, turn)
    Player.resetSubmission(playerData)
    Player.drawCard(playerData)
end

function Player.reset(playerData, deck)
    playerData.deck = deck or {}
    playerData.hand = {}
    playerData.discard = {}
    playerData.mana = PlayerState.DEFAULT_MANA
    playerData.bonusMana = PlayerState.INITIAL_BONUS_MANA
    playerData.points = PlayerState.INITIAL_POINTS
    playerData.submitted = false
end

function Player.boostHandPower(playerData, amount)
    amount = amount or 1
    for _, card in ipairs(playerData.hand) do
        card.power = card.power + amount
    end
end

function Player.reduceHandPower(playerData, amount)
    amount = amount or 1
    for _, card in ipairs(playerData.hand) do
        card.power = math.max(PlayerState.MIN_POWER, card.power - amount)
    end
end

function Player.getValidPlays(playerData, locations)
    local validPlays = {}
    
    for i, card in ipairs(playerData.hand) do
        if card.cost <= playerData.mana then
            for j = 1, #locations do
                local playerCards = playerData == player and locations[j].playerCards or locations[j].opponentCards
                if #playerCards < Game.SLOTS_PER_LOCATION then
                    table.insert(validPlays, {card = card, location = j})
                end
            end
        end
    end
    
    return validPlays
end

function Player.getHand(playerData)
    return playerData.hand
end

function Player.getDeck(playerData)
    return playerData.deck
end

function Player.getDiscard(playerData)
    return playerData.discard
end

return Player