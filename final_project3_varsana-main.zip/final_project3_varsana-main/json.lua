local json = {}

local function skip_whitespace(str, pos)
    while pos <= #str and str:sub(pos, pos):match("%s") do
        pos = pos + 1
    end
    return pos
end

local function parse_string(str, pos)
    if str:sub(pos, pos) ~= '"' then
        error("Expected string at position " .. pos)
    end
    pos = pos + 1
    local start = pos
    while pos <= #str and str:sub(pos, pos) ~= '"' do
        if str:sub(pos, pos) == '\\' then
            pos = pos + 2
        else
            pos = pos + 1
        end
    end
    if pos > #str then
        error("Unterminated string")
    end
    local result = str:sub(start, pos - 1)
    pos = pos + 1
    return result, pos
end

local function parse_number(str, pos)
    local start = pos
    if str:sub(pos, pos) == '-' then
        pos = pos + 1
    end
    while pos <= #str and str:sub(pos, pos):match("%d") do
        pos = pos + 1
    end
    if pos <= #str and str:sub(pos, pos) == '.' then
        pos = pos + 1
        while pos <= #str and str:sub(pos, pos):match("%d") do
            pos = pos + 1
        end
    end
    local numstr = str:sub(start, pos - 1)
    return tonumber(numstr), pos
end

local function parse_value(str, pos)
    pos = skip_whitespace(str, pos)
    if pos > #str then
        error("Unexpected end of input")
    end
    
    local char = str:sub(pos, pos)
    if char == '"' then
        return parse_string(str, pos)
    elseif char:match("[%d%-]") then
        return parse_number(str, pos)
    elseif char == '{' then
        return parse_object(str, pos)
    elseif char == '[' then
        return parse_array(str, pos)
    elseif str:sub(pos, pos + 3) == "true" then
        return true, pos + 4
    elseif str:sub(pos, pos + 4) == "false" then
        return false, pos + 5
    elseif str:sub(pos, pos + 3) == "null" then
        return nil, pos + 4
    else
        error("Unexpected character at position " .. pos .. ": " .. char)
    end
end

function parse_object(str, pos)
    if str:sub(pos, pos) ~= '{' then
        error("Expected object at position " .. pos)
    end
    pos = pos + 1
    local obj = {}
    pos = skip_whitespace(str, pos)
    
    if str:sub(pos, pos) == '}' then
        return obj, pos + 1
    end
    
    while true do
        pos = skip_whitespace(str, pos)
        local key, new_pos = parse_string(str, pos)
        pos = new_pos
        pos = skip_whitespace(str, pos)
        
        if str:sub(pos, pos) ~= ':' then
            error("Expected ':' at position " .. pos)
        end
        pos = pos + 1
        
        local value
        value, pos = parse_value(str, pos)
        obj[key] = value
        
        pos = skip_whitespace(str, pos)
        if str:sub(pos, pos) == '}' then
            return obj, pos + 1
        elseif str:sub(pos, pos) == ',' then
            pos = pos + 1
        else
            error("Expected ',' or '}' at position " .. pos)
        end
    end
end

function parse_array(str, pos)
    if str:sub(pos, pos) ~= '[' then
        error("Expected array at position " .. pos)
    end
    pos = pos + 1
    local arr = {}
    pos = skip_whitespace(str, pos)
    
    if str:sub(pos, pos) == ']' then
        return arr, pos + 1
    end
    
    while true do
        local value
        value, pos = parse_value(str, pos)
        table.insert(arr, value)
        
        pos = skip_whitespace(str, pos)
        if str:sub(pos, pos) == ']' then
            return arr, pos + 1
        elseif str:sub(pos, pos) == ',' then
            pos = pos + 1
            pos = skip_whitespace(str, pos)
        else
            error("Expected ',' or ']' at position " .. pos)
        end
    end
end

function json.decode(str)
    local value, pos = parse_value(str, 1)
    pos = skip_whitespace(str, pos)
    if pos <= #str then
        error("Extra characters after JSON")
    end
    return value
end

return json