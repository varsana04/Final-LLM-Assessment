require("game")
require("player")
require("observer")

local Config = {
    WINDOW_WIDTH = 1200,
    WINDOW_HEIGHT = 800,
    CARD_WIDTH = 100,
    CARD_HEIGHT = 140,
    GAME_STATE = {
        TITLE = "title",
        PLAYING = "playing",
        GAME_OVER = "game_over"
    }
}

WINDOW_WIDTH = Config.WINDOW_WIDTH
WINDOW_HEIGHT = Config.WINDOW_HEIGHT
CARD_WIDTH = Config.CARD_WIDTH
CARD_HEIGHT = Config.CARD_HEIGHT
GAME_STATE = Config.GAME_STATE

local GameState = {
    current = GAME_STATE.TITLE
}

local Assets = {
    backgroundImage = nil,
    titleFont = nil,
    titlenormal = nil,
    headerFont = nil,
    normalFont = nil,
    smallFont = nil,
    cardFont = nil,
    cardImages = {}
}

local DragSystem = {
    draggedCard = nil,
    dragOffsetX = 0,
    dragOffsetY = 0,
    dragStartX = 0,
    dragStartY = 0,
    dragCurrentX = 0,
    dragCurrentY = 0,
    dragPrevX = 0,
    dragPrevY = 0,
    dragVelocityX = 0,
    dragVelocityY = 0,
    dragStartTime = 0,
    dragTilt = 0,
    dragScale = 1.0,
    dragBounce = 0,
    dragTrail = {}
}

local HoverSystem = {
    hoveredCard = nil,
    hoverCardIndex = nil,
    hoverScale = 1.0,
    hoverBob = 0,
    hoverTime = 0
}

local InspectionSystem = {
    inspectedCard = nil,
    inspectionX = 0,
    inspectionY = 0
}

gameState = GameState.current
draggedCard = DragSystem.draggedCard
dragOffsetX = DragSystem.dragOffsetX
dragOffsetY = DragSystem.dragOffsetY
dragStartX = DragSystem.dragStartX
dragStartY = DragSystem.dragStartY
dragCurrentX = DragSystem.dragCurrentX
dragCurrentY = DragSystem.dragCurrentY
dragPrevX = DragSystem.dragPrevX
dragPrevY = DragSystem.dragPrevY
dragVelocityX = DragSystem.dragVelocityX
dragVelocityY = DragSystem.dragVelocityY
dragStartTime = DragSystem.dragStartTime
dragTilt = DragSystem.dragTilt
dragScale = DragSystem.dragScale
dragBounce = DragSystem.dragBounce
dragTrail = DragSystem.dragTrail
hoveredCard = HoverSystem.hoveredCard
hoverCardIndex = HoverSystem.hoverCardIndex
hoverScale = HoverSystem.hoverScale
hoverBob = HoverSystem.hoverBob
hoverTime = HoverSystem.hoverTime
inspectedCard = InspectionSystem.inspectedCard
inspectionX = InspectionSystem.inspectionX
inspectionY = InspectionSystem.inspectionY

local function initializeAssets()
    local success, errorMsg = pcall(function()
        Assets.backgroundImage = love.graphics.newImage("assets/background_p3.jpeg") 
    end)
    
    if not success then
        Assets.backgroundImage = nil
    end
    
    Assets.titleFont = love.graphics.newFont(30)
    Assets.titlenormal = love.graphics.newFont(20)
    Assets.headerFont = love.graphics.newFont(20)
    Assets.normalFont = love.graphics.newFont(12)  
    Assets.smallFont = love.graphics.newFont(14)
    Assets.cardFont = love.graphics.newFont(10)
    
    Assets.cardImages = {
        front = love.graphics.newImage("assets/images/Card_0.png"),
        back = love.graphics.newImage("assets/images/Card_Back_0.png")
    }
end

local function setupObservers()
    Observer.addObserver("gameStateChange", function(data)
        gameState = data.newState
        GameState.current = data.newState
    end)
    
    Observer.addObserver("cardDragged", function(data)
        draggedCard = data.card
        DragSystem.draggedCard = data.card
    end)
    
    Observer.addObserver("cardHovered", function(data)
        hoveredCard = data.card
        hoverCardIndex = data.index
        HoverSystem.hoveredCard = data.card
        HoverSystem.hoverCardIndex = data.index
    end)
end

local function updateDragSystem(dt)
    if DragSystem.draggedCard then
        local mouseX, mouseY = love.mouse.getPosition()
        DragSystem.dragPrevX = DragSystem.dragCurrentX
        DragSystem.dragPrevY = DragSystem.dragCurrentY
        DragSystem.dragCurrentX = mouseX - DragSystem.dragOffsetX
        DragSystem.dragCurrentY = mouseY - DragSystem.dragOffsetY
        
        DragSystem.dragVelocityX = (DragSystem.dragCurrentX - DragSystem.dragPrevX) / dt
        DragSystem.dragVelocityY = (DragSystem.dragCurrentY - DragSystem.dragPrevY) / dt
        
        local targetTilt = math.max(-0.3, math.min(0.3, DragSystem.dragVelocityX * 0.001))
        DragSystem.dragTilt = DragSystem.dragTilt + (targetTilt - DragSystem.dragTilt) * dt * 8
        
        local targetScale = 1.1
        DragSystem.dragScale = DragSystem.dragScale + (targetScale - DragSystem.dragScale) * dt * 6
        
        local locationWidth = WINDOW_WIDTH / 3
        local overValidZone = false
        for i = 1, Game.LOCATIONS_COUNT do
            local locX = (i - 1) * locationWidth
            local locY = 270
            if mouseX >= locX and mouseX <= locX + locationWidth and mouseY >= locY and mouseY <= locY + 80 then
                if Game.canPlayCardAtLocation(i) then
                    overValidZone = true
                    break
                end
            end
        end
        
        if overValidZone then
            DragSystem.dragBounce = DragSystem.dragBounce + dt * 12
        else
            DragSystem.dragBounce = DragSystem.dragBounce * 0.95
        end
        
        table.insert(DragSystem.dragTrail, 1, {
            x = DragSystem.dragCurrentX + CARD_WIDTH/2, 
            y = DragSystem.dragCurrentY + CARD_HEIGHT/2, 
            time = love.timer.getTime()
        })
        
        for i = #DragSystem.dragTrail, 1, -1 do
            if love.timer.getTime() - DragSystem.dragTrail[i].time > 0.3 then
                table.remove(DragSystem.dragTrail, i)
            end
        end
    else
        DragSystem.dragScale = DragSystem.dragScale + (1.0 - DragSystem.dragScale) * dt * 8
        DragSystem.dragTilt = DragSystem.dragTilt * 0.9
        DragSystem.dragBounce = 0
        DragSystem.dragTrail = {}
    end
    
    draggedCard = DragSystem.draggedCard
    dragCurrentX = DragSystem.dragCurrentX
    dragCurrentY = DragSystem.dragCurrentY
    dragTilt = DragSystem.dragTilt
    dragScale = DragSystem.dragScale
    dragBounce = DragSystem.dragBounce
    dragTrail = DragSystem.dragTrail
end

local function updateHoverSystem(dt)
    local mouseX, mouseY = love.mouse.getPosition()
    local newHoveredCard = nil
    local newHoverIndex = nil
    
    if not DragSystem.draggedCard and not InspectionSystem.inspectedCard then
        local playerHand = Player.getHand(Game.getPlayer())
        for i, card in ipairs(playerHand) do
            local cardX = 10 + (i - 1) * 110
            local cardY = 520
            
            if mouseX >= cardX and mouseX <= cardX + CARD_WIDTH and mouseY >= cardY and mouseY <= cardY + CARD_HEIGHT then
                newHoveredCard = card
                newHoverIndex = i
                break
            end
        end
    end
    
    if newHoveredCard ~= HoverSystem.hoveredCard then
        HoverSystem.hoveredCard = newHoveredCard
        HoverSystem.hoverCardIndex = newHoverIndex
        HoverSystem.hoverTime = 0
    end
    
    if HoverSystem.hoveredCard then
        HoverSystem.hoverTime = HoverSystem.hoverTime + dt
        local targetScale = 1.05
        HoverSystem.hoverScale = HoverSystem.hoverScale + (targetScale - HoverSystem.hoverScale) * dt * 8
        HoverSystem.hoverBob = math.sin(HoverSystem.hoverTime * 6) * 3
    else
        HoverSystem.hoverScale = HoverSystem.hoverScale + (1.0 - HoverSystem.hoverScale) * dt * 8
        HoverSystem.hoverBob = HoverSystem.hoverBob * 0.9
    end
    
    hoveredCard = HoverSystem.hoveredCard
    hoverCardIndex = HoverSystem.hoverCardIndex
    hoverScale = HoverSystem.hoverScale
    hoverBob = HoverSystem.hoverBob
end

local function setupWindow()
    love.window.setTitle("TITANS CLASH")
    love.window.setMode(WINDOW_WIDTH, WINDOW_HEIGHT)
    love.graphics.setBackgroundColor(0.05, 0.05, 0.1)
end

backgroundImage = Assets.backgroundImage
titleFont = Assets.titleFont
titlenormal = Assets.titlenormal
headerFont = Assets.headerFont
normalFont = Assets.normalFont
smallFont = Assets.smallFont
cardFont = Assets.cardFont
cardImages = Assets.cardImages

function love.load()
    Game.loadCardData()
    Game.load() 
    setupWindow()
    initializeAssets()
    setupObservers()
    math.randomseed(os.time())
    Game.loadSounds()
    
    backgroundImage = Assets.backgroundImage
    titleFont = Assets.titleFont
    titlenormal = Assets.titlenormal
    headerFont = Assets.headerFont
    normalFont = Assets.normalFont
    smallFont = Assets.smallFont
    cardFont = Assets.cardFont
    cardImages = Assets.cardImages
end

function love.update(dt)
    if GameState.current == GAME_STATE.PLAYING then
        Game.update()
        updateDragSystem(dt)
        updateHoverSystem(dt)
    end
end

local function drawBackground()
    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.setLineWidth(1)
    
    if Assets.backgroundImage then
        love.graphics.setColor(1, 1, 1, 0.7)
        love.graphics.draw(Assets.backgroundImage, 0, 0, 0, 
            WINDOW_WIDTH / Assets.backgroundImage:getWidth(), 
            WINDOW_HEIGHT / Assets.backgroundImage:getHeight())
    end
    
    love.graphics.setColor(0, 0, 0, 0.3)
    love.graphics.rectangle("fill", 0, 0, WINDOW_WIDTH, WINDOW_HEIGHT)
    love.graphics.setColor(1, 1, 1, 1)
end

local function drawTitleScreen()
    love.graphics.setColor(1, 0.8, 0)
    love.graphics.setFont(Assets.titleFont)
    love.graphics.printf("TITANS CLASH", 0, WINDOW_HEIGHT/2 - 100, WINDOW_WIDTH, "center")
    love.graphics.setFont(Assets.titlenormal)
    love.graphics.setColor(1, 1, 1)
    love.graphics.printf("A Strategic Card Game", 0, WINDOW_HEIGHT/2 - 50, WINDOW_WIDTH, "center")
    love.graphics.printf("Press SPACE to Start", 0, WINDOW_HEIGHT/2 + 50, WINDOW_WIDTH, "center")
end

local function drawGameOverScreen()
    love.graphics.setColor(1, 0.8, 0)
    love.graphics.setFont(Assets.titleFont)
    love.graphics.printf("GAME OVER", 0, WINDOW_HEIGHT/2 - 100, WINDOW_WIDTH, "center")
    love.graphics.setFont(Assets.titlenormal)
    love.graphics.setColor(1, 1, 1)
    love.graphics.printf("Winner: " .. Game.getWinner(), 0, WINDOW_HEIGHT/2 - 50, WINDOW_WIDTH, "center")
    love.graphics.printf("Final Score - Player: " .. Player.getPoints(Game.getPlayer()) .. " | Opponent: " .. Player.getPoints(Game.getOpponent()), 0, WINDOW_HEIGHT/2, WINDOW_WIDTH, "center")
    love.graphics.printf("Press R to Restart", 0, WINDOW_HEIGHT/2 + 50, WINDOW_WIDTH, "center")
end

local function drawEnhancedPlayerHand()
    local playerHand = Player.getHand(Game.getPlayer())
    local playerMana = Player.getMana(Game.getPlayer())
    
    for i, card in ipairs(playerHand) do
        if card ~= DragSystem.draggedCard then
            local cardX = 10 + (i - 1) * 110
            local cardY = 520
            
            local scale = 1.0
            local offsetY = 0
            if HoverSystem.hoverCardIndex == i then
                scale = HoverSystem.hoverScale
                offsetY = HoverSystem.hoverBob
            end
            
            love.graphics.push()
            love.graphics.translate(cardX + CARD_WIDTH/2, cardY + CARD_HEIGHT/2 + offsetY)
            love.graphics.scale(scale, scale)
            love.graphics.translate(-CARD_WIDTH/2, -CARD_HEIGHT/2)
            
            if card.cost > playerMana then
                love.graphics.setColor(0.7, 0.7, 0.7, 0.7)
            else
                love.graphics.setColor(1, 1, 1, 1)
            end
            
            love.graphics.draw(Assets.cardImages.front, 0, 0, 0, 
                CARD_WIDTH/Assets.cardImages.front:getWidth(), 
                CARD_HEIGHT/Assets.cardImages.front:getHeight())
            
            if card.cost <= playerMana and HoverSystem.hoverCardIndex == i then
                love.graphics.setColor(1, 0.8, 0, 0.8)
                love.graphics.setLineWidth(3)
                love.graphics.rectangle("line", 0, 0, CARD_WIDTH, CARD_HEIGHT, 5, 5)
            end
            
            love.graphics.setColor(1, 1, 1, 1)
            love.graphics.setFont(Assets.cardFont)
         
            love.graphics.printf(card.name, 5, 5, CARD_WIDTH - 10, "center")
            love.graphics.setColor(0, 0, 0, 1)
            love.graphics.printf("Cost: " .. card.cost, 5,35, CARD_WIDTH - 10, "center")
            love.graphics.printf("Power: " .. card.power, 5, 45, CARD_WIDTH - 10, "center")
            
            love.graphics.pop()
        end
    end
end

local function drawDragTrail()
    if #DragSystem.dragTrail > 1 then
        for i = 2, #DragSystem.dragTrail do
            local point = DragSystem.dragTrail[i]
            local alpha = math.max(0, 1 - (i / #DragSystem.dragTrail))
            local size = alpha * 4
            if size > 0.5 then
                love.graphics.setColor(0, 0.8, 0, alpha * 0.15)
                love.graphics.circle("fill", point.x, point.y, size)
            end
        end
    end
end

local function drawDraggedCard()
    local currentR, currentG, currentB, currentA = love.graphics.getColor()
    local currentLineWidth = love.graphics.getLineWidth()
    
    drawDragTrail()
    
    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.setLineWidth(1)
    
    love.graphics.push()
    
    love.graphics.translate(DragSystem.dragCurrentX + CARD_WIDTH/2, DragSystem.dragCurrentY + CARD_HEIGHT/2)
    
    local totalScale = DragSystem.dragScale + math.sin(DragSystem.dragBounce) * 0.05
    love.graphics.scale(totalScale, totalScale)
    
    love.graphics.rotate(DragSystem.dragTilt)
    
    local floatOffset = math.sin(love.timer.getTime() * 4) * 2
    love.graphics.translate(0, floatOffset)
    
    love.graphics.translate(-CARD_WIDTH/2, -CARD_HEIGHT/2)
    
    love.graphics.setColor(0, 0, 0, 0.3)
    love.graphics.rectangle("fill", 5, 5, CARD_WIDTH, CARD_HEIGHT, 5, 5)
    

    
    love.graphics.setColor(1, 1, 1, 0.95)
    love.graphics.draw(Assets.cardImages.front, 0, 0, 0, 
    CARD_WIDTH/Assets.cardImages.front:getWidth(), 
    CARD_HEIGHT/Assets.cardImages.front:getHeight())
  
    local mouseX, mouseY = love.mouse.getPosition()
    local locationWidth = WINDOW_WIDTH / 3
    local overValidZone = false
    
    for i = 1, Game.LOCATIONS_COUNT do
        local locX = (i - 1) * locationWidth
        local locY = 270
        if mouseX >= locX and mouseX <= locX + locationWidth and mouseY >= locY and mouseY <= locY + 80 then
            if Game.canPlayCardAtLocation(i) then
                overValidZone = true
                break
            end
        end
    end
    
    if overValidZone then
        love.graphics.setColor(0, 1, 0, 0.9)
        love.graphics.setLineWidth(4)
        love.graphics.rectangle("line", 0, 0, CARD_WIDTH, CARD_HEIGHT, 5, 5)
        
        love.graphics.setColor(0, 1, 0, 0.4)
        love.graphics.setLineWidth(2)
        love.graphics.rectangle("line", -3, -3, CARD_WIDTH + 6, CARD_HEIGHT + 6, 8, 8)
    else
        love.graphics.setColor(0, 0.8, 0, 0.9)
        love.graphics.setLineWidth(3)
        love.graphics.rectangle("line", 0, 0, CARD_WIDTH, CARD_HEIGHT, 5, 5)
        
        love.graphics.setColor(0, 0.8, 0, 0.2)
        love.graphics.setLineWidth(1)
        love.graphics.rectangle("line", -2, -2, CARD_WIDTH + 4, CARD_HEIGHT + 4, 7, 7)
    end
    
    love.graphics.setLineWidth(1)
    love.graphics.setColor(0, 0, 0, 1)
    love.graphics.setFont(Assets.cardFont)
    love.graphics.printf(DragSystem.draggedCard.name, 5, 5, CARD_WIDTH - 10, "center")
    love.graphics.printf("Cost: " .. DragSystem.draggedCard.cost,  5, 35, CARD_WIDTH - 10, "center")
    love.graphics.printf("Power: " .. DragSystem.draggedCard.power, 5,45, CARD_WIDTH - 10, "center")
    love.graphics.printf(DragSystem.draggedCard.text:sub(1, 50), 5, 70, CARD_WIDTH - 10, "center")
    
    love.graphics.pop()
    
    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.setLineWidth(1)
end

local function drawCardInspection()
    love.graphics.setColor(0, 0, 0, 0.7)
    love.graphics.rectangle("fill", 0, 0, WINDOW_WIDTH, WINDOW_HEIGHT)
    
    local cardWidth = 200
    local cardHeight = 280
    local cardX = (WINDOW_WIDTH - cardWidth) / 2
    local cardY = (WINDOW_HEIGHT - cardHeight) / 2
    
    love.graphics.setColor(0.2, 0.2, 0.3)
    love.graphics.rectangle("fill", cardX, cardY, cardWidth, cardHeight)
    
    love.graphics.setColor(1, 1, 1)
    love.graphics.rectangle("line", cardX, cardY, cardWidth, cardHeight, 5, 5)
    
    love.graphics.setFont(Assets.headerFont)
    love.graphics.setColor(1, 0.8, 0)
    love.graphics.printf(InspectionSystem.inspectedCard.name, cardX + 10, cardY + 10, cardWidth - 20, "center")
    
    love.graphics.setFont(Assets.normalFont)
    love.graphics.setColor(1, 1, 1)
    
    if InspectionSystem.inspectedCard.basePower and InspectionSystem.inspectedCard.basePower ~= InspectionSystem.inspectedCard.power then
        love.graphics.setColor(0.7, 0.7, 0.7)
        love.graphics.printf("(Base: " .. InspectionSystem.inspectedCard.basePower .. ")", cardX + 10, cardY + 90, cardWidth - 20, "left")
        love.graphics.setColor(1, 1, 1)
    end
    
    love.graphics.setFont(Assets.smallFont)
    love.graphics.setColor(0.9, 0.9, 0.9)
    love.graphics.printf(InspectionSystem.inspectedCard.text, cardX + 10, cardY + 120, cardWidth - 20, "left")
    
    if InspectionSystem.inspectedCard.location then
        love.graphics.setColor(0.8, 0.8, 1)
        love.graphics.printf("Location: " .. InspectionSystem.inspectedCard.location, cardX + 10, cardY + 200, cardWidth - 20, "left")
    end
    
    love.graphics.setFont(Assets.smallFont)
    love.graphics.setColor(1, 0.8, 0)
    love.graphics.printf("Right-click or ESC to close", cardX + 10, cardY + cardHeight - 30, cardWidth - 20, "center")
end

function love.draw()
    drawBackground()
    
    if GameState.current == GAME_STATE.TITLE then
        drawTitleScreen()
    elseif GameState.current == GAME_STATE.PLAYING then
        Game.draw()
        drawEnhancedPlayerHand()
        
        if DragSystem.draggedCard then
            drawDraggedCard()
        end
        
        if InspectionSystem.inspectedCard then
            drawCardInspection()
        end
    elseif GameState.current == GAME_STATE.GAME_OVER then
        drawGameOverScreen()
    end
    
    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.setLineWidth(1)
end

function getCardAtPosition(x, y)
    local playerHand = Player.getHand(Game.getPlayer())
    for i, card in ipairs(playerHand) do
        local cardX = 10 + (i - 1) * 110
        local cardY = 520
        
        if x >= cardX and x <= cardX + CARD_WIDTH and y >= cardY and y <= cardY + CARD_HEIGHT then
            return card
        end
    end
    
    return Game.getCardAtLocationPosition(x, y)
end

local function handleTitleInput(key)
    if key == "space" then
        Game.initialize()
        GameState.current = GAME_STATE.PLAYING
        gameState = GameState.current
    end
end

local function handleGameOverInput(key)
    if key == "r" then
        GameState.current = GAME_STATE.TITLE
        gameState = GameState.current
    end
end

local function handlePlayingInput(key)
    if key == "escape" then
        InspectionSystem.inspectedCard = nil
        inspectedCard = InspectionSystem.inspectedCard
    elseif key == "return" and not Player.hasSubmitted(Game.getPlayer()) then
        Player.submit(Game.getPlayer())
    elseif key == "u" and not Player.hasSubmitted(Game.getPlayer()) then
        Game.undoLastPlay()
    end
end

function love.keypressed(key)
    if GameState.current == GAME_STATE.TITLE then
        handleTitleInput(key)
    elseif GameState.current == GAME_STATE.GAME_OVER then
        handleGameOverInput(key)
    elseif GameState.current == GAME_STATE.PLAYING then
        handlePlayingInput(key)
    end
end

local function handleRightClick(x, y)
    if InspectionSystem.inspectedCard then
        InspectionSystem.inspectedCard = nil
        inspectedCard = InspectionSystem.inspectedCard
        return true
    end
    
    local cardToInspect = getCardAtPosition(x, y)
    if cardToInspect then
        InspectionSystem.inspectedCard = cardToInspect
        InspectionSystem.inspectionX = x
        InspectionSystem.inspectionY = y
        inspectedCard = InspectionSystem.inspectedCard
        inspectionX = InspectionSystem.inspectionX
        inspectionY = InspectionSystem.inspectionY
        return true
    end
    
    return false
end

local function handleUIButtons(x, y)
    if x >= WINDOW_WIDTH - 120 and x <= WINDOW_WIDTH - 20 and y >= 10 and y <= 40 and not Player.hasSubmitted(Game.getPlayer()) then
        Player.submit(Game.getPlayer())
        return true
    end
    
    if x >= WINDOW_WIDTH - 240 and x <= WINDOW_WIDTH - 140 and y >= 10 and y <= 40 and not Player.hasSubmitted(Game.getPlayer()) then
        Game.undoLastPlay()
        return true
    end
    
    return false
end

local function handleCardDrag(x, y)
    local playerHand = Player.getHand(Game.getPlayer())
    local playerMana = Player.getMana(Game.getPlayer())
    
    for i, card in ipairs(playerHand) do
        local cardX = 10 + (i - 1) * 110
        local cardY = 520
        
        if x >= cardX and x <= cardX + CARD_WIDTH and y >= cardY and y <= cardY + CARD_HEIGHT then
            if card.cost <= playerMana then
                DragSystem.draggedCard = card
                DragSystem.dragOffsetX = x - cardX
                DragSystem.dragOffsetY = y - cardY
                DragSystem.dragStartX = cardX
                DragSystem.dragStartY = cardY
                DragSystem.dragCurrentX = cardX
                DragSystem.dragCurrentY = cardY
                DragSystem.dragPrevX = cardX
                DragSystem.dragPrevY = cardY
                DragSystem.dragStartTime = love.timer.getTime()
                DragSystem.dragTrail = {}
                
                
                draggedCard = DragSystem.draggedCard
                dragOffsetX = DragSystem.dragOffsetX
                dragOffsetY = DragSystem.dragOffsetY
                dragStartX = DragSystem.dragStartX
                dragStartY = DragSystem.dragStartY
                dragCurrentX = DragSystem.dragCurrentX
                dragCurrentY = DragSystem.dragCurrentY
                dragPrevX = DragSystem.dragPrevX
                dragPrevY = DragSystem.dragPrevY
                dragStartTime = DragSystem.dragStartTime
                dragTrail = DragSystem.dragTrail
                
            end
            return true
        end
    end
    
    return false
end

function love.mousepressed(x, y, button)
    if GameState.current == GAME_STATE.PLAYING then
        if button == 2 then
            handleRightClick(x, y)
            return
        end
        
        if InspectionSystem.inspectedCard then
            return
        end
        
        if button == 1 then
            if handleUIButtons(x, y) then
                return
            end
            
            handleCardDrag(x, y)
        end
    end
end

function love.mousereleased(x, y, button)
    if GameState.current == GAME_STATE.PLAYING and button == 1 and DragSystem.draggedCard then
        local locationWidth = WINDOW_WIDTH / 3
        local cardPlayed = false
        
        for i = 1, Game.LOCATIONS_COUNT do
            local locX = (i - 1) * locationWidth
            local locY = 270
            
            if x >= locX and x <= locX + locationWidth and y >= locY and y <= locY + 80 then
                if Game.canPlayCardAtLocation(i) then
                    Game.playCard(DragSystem.draggedCard, Game.getPlayer(), i)
                    cardPlayed = true
                end
                break
            end
        end
        
        DragSystem.draggedCard = nil
        DragSystem.dragTrail = {}
        draggedCard = DragSystem.draggedCard
        dragTrail = DragSystem.dragTrail
    end
end