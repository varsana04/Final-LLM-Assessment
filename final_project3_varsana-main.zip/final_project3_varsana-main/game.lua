Game = {}
local sounds = {}
local faceDownCardImage

Game.HAND_SIZE = 7
Game.DECK_SIZE = 20
Game.STARTING_HAND = 3
Game.LOCATIONS_COUNT = 3
Game.SLOTS_PER_LOCATION = 4
Game.WIN_POINTS = 20

local turn = 1
local gameOver = false
local winner = nil
local player = nil
local opponent = nil
local locations = {}
local cardData = {}
local playerPlayHistory = {}

for i = 1, Game.LOCATIONS_COUNT do
    locations[i] = {
        name = "Location " .. i,
        playerCards = {},
        opponentCards = {},
        playerPower = 0,
        opponentPower = 0
    }
end

local cardFrames = {}

function Game.load()
    local success, msg = pcall(function()
        faceDownCardImage = love.graphics.newImage("assets/images/Card_Back_0.png")
    end)
    
    if not success then
        faceDownCardImage = nil
    end
    
    local success2, msg2 = pcall(function()
        cardFrontImage = love.graphics.newImage("assets/images/Card_0.png")
    end)
    
    if not success2 then
        cardFrontImage = nil
    end
end

function Game.loadSounds()
    sounds.cardFlip = love.audio.newSource("sounds/flipcard-91468.mp3", "static") 
    sounds.success = love.audio.newSource("sounds/success-1-6297.mp3", "static")  
end

function Game.loadCardData()
    local json = require("json")
    local file = love.filesystem.read("cards.json")
    if file then
        cardData = json.decode(file)
    else
        error("Could not load cards.json file!")
    end
end

local function createCard(cardDataItem)
    return {
        name = cardDataItem.name,
        cost = cardDataItem.cost,
        basePower = cardDataItem.power,
        power = cardDataItem.power,
        text = cardDataItem.text,
        effect = cardDataItem.effect,
        x = 0,
        y = 0,
        faceDown = false,
        location = nil
    }
end

local function shuffleDeck(deck)
    for i = #deck, 2, -1 do
        local j = math.random(i)
        deck[i], deck[j] = deck[j], deck[i]
    end
end

local function createDeck()
    local deck = {}
    for _, cardDataItem in ipairs(cardData) do
        for i = 1, 2 do
            table.insert(deck, createCard(cardDataItem))
        end
    end
    
    while #deck > Game.DECK_SIZE do
        table.remove(deck, math.random(#deck))
    end
    
    shuffleDeck(deck)
    return deck
end

local function executeCardEffect(card, playerData, locationIndex)
    local effect = card.effect
    
    if effect == "reduce_opponent_hand" then
        local targetPlayer = (playerData == player) and opponent or player
        for _, handCard in ipairs(Player.getHand(targetPlayer)) do
            handCard.power = math.max(1, handCard.power - 1)
        end
    elseif effect == "power_per_enemy" then
        local enemyCards = (playerData == player) and locations[locationIndex].opponentCards or locations[locationIndex].playerCards
        card.power = card.power + (#enemyCards * 2)
    elseif effect == "reduce_others" then
        for _, otherCard in ipairs(locations[locationIndex].playerCards) do
            if otherCard ~= card then
                otherCard.power = math.max(1, otherCard.power - 1)
            end
        end
        for _, otherCard in ipairs(locations[locationIndex].opponentCards) do
            otherCard.power = math.max(1, otherCard.power - 1)
        end
    elseif effect == "remove_weakest" then
        local enemyCards = (playerData == player) and locations[locationIndex].opponentCards or locations[locationIndex].playerCards
        if #enemyCards > 0 then
            local weakest = enemyCards[1]
            for _, enemyCard in ipairs(enemyCards) do
                if enemyCard.power < weakest.power then
                    weakest = enemyCard
                end
            end
            for i, enemyCard in ipairs(enemyCards) do
                if enemyCard == weakest then
                    table.remove(enemyCards, i)
                    local targetPlayer = (playerData == player) and opponent or player
                    table.insert(Player.getDiscard(targetPlayer), enemyCard)
                    break
                end
            end
        end
    elseif effect == "power_if_one" then
        local enemyCards = (playerData == player) and locations[locationIndex].opponentCards or locations[locationIndex].playerCards
        if #enemyCards == 1 then
            card.power = card.power + 5
        end
    elseif effect == "boost_hand" then
        for _, handCard in ipairs(Player.getHand(playerData)) do
            handCard.power = handCard.power + 1
        end
    elseif effect == "both_draw" then
        Player.drawCard(player)
        Player.drawCard(opponent)
    elseif effect == "power_per_discard" then
        card.power = card.power + (#Player.getDiscard(playerData) * 2)
    elseif effect == "equalize_power" then
        for _, cardAtLocation in ipairs(locations[locationIndex].playerCards) do
            cardAtLocation.power = 3
        end
        for _, cardAtLocation in ipairs(locations[locationIndex].opponentCards) do
            cardAtLocation.power = 3
        end    
    elseif effect == "double_if_strongest" then
        local allCards = {}
        for _, c in ipairs(locations[locationIndex].playerCards) do
            table.insert(allCards, c)
        end
        for _, c in ipairs(locations[locationIndex].opponentCards) do
            table.insert(allCards, c)
        end
        
        local isStrongest = true
        for _, c in ipairs(allCards) do
            if c ~= card and c.power > card.power then
                isStrongest = false
                break
            end
        end
        
        if isStrongest then
            card.power = card.power * 2
        end
    elseif effect == "power_per_ally" then
        local allyCards = (playerData == player) and locations[locationIndex].playerCards or locations[locationIndex].opponentCards
        card.power = card.power + ((#allyCards - 1) * 2)
    elseif effect == "bonus_mana" then
        Player.addBonusMana(playerData, 1)
    end
    
    Observer.notify("cardEffectExecuted", {
        card = card,
        player = playerData,
        location = locationIndex,
        effect = card.effect
    })
end

local function calculateLocationPowers()
    for i, location in ipairs(locations) do
        location.playerPower = 0
        location.opponentPower = 0
        
        for _, card in ipairs(location.playerCards) do
            location.playerPower = location.playerPower + card.power
        end
        
        for _, card in ipairs(location.opponentCards) do
            location.opponentPower = location.opponentPower + card.power
        end
    end
end

local function awardPoints()
    for _, location in ipairs(locations) do
        local diff = location.playerPower - location.opponentPower
        if diff > 0 then
            Player.addPoints(player, diff)
        elseif diff < 0 then
            Player.addPoints(opponent, math.abs(diff))
        end
    end
end

local function checkWinCondition()
    if Player.getPoints(player) >= Game.WIN_POINTS or Player.getPoints(opponent) >= Game.WIN_POINTS then
        gameOver = true
        local playerPoints = Player.getPoints(player)
        local opponentPoints = Player.getPoints(opponent)
        
        if playerPoints >= Game.WIN_POINTS and opponentPoints >= Game.WIN_POINTS then
            if playerPoints > opponentPoints then
                winner = "Player"
                if sounds.success then
                    love.audio.play(sounds.success)
                end
            elseif opponentPoints > playerPoints then
                winner = "Opponent"
            else
                winner = "Tie"
            end
        elseif playerPoints >= Game.WIN_POINTS then
            winner = "Player"
            if sounds.success then
                love.audio.play(sounds.success)
            end
        else
            winner = "Opponent"
        end
        gameState = GAME_STATE.GAME_OVER
        
        Observer.notify("gameOver", {
            winner = winner,
            playerPoints = Player.getPoints(player),
            opponentPoints = Player.getPoints(opponent)
        })
        
        Observer.notify("gameStateChange", {
            newState = GAME_STATE.GAME_OVER
        })
    end
end

local function aiTurn()
    local validPlays = {}
    
    for i, card in ipairs(Player.getHand(opponent)) do
        if card.cost <= Player.getMana(opponent) then
            for j = 1, Game.LOCATIONS_COUNT do
                if #locations[j].opponentCards < Game.SLOTS_PER_LOCATION then
                    table.insert(validPlays, {card = card, location = j})
                end
            end
        end
    end
    
    while #validPlays > 0 and Player.getMana(opponent) > 0 do
        local randomIndex = math.random(#validPlays)
        local play = validPlays[randomIndex]
        
        if Game.playCard(play.card, opponent, play.location) then
            validPlays = {}
            for i, card in ipairs(Player.getHand(opponent)) do
                if card.cost <= Player.getMana(opponent) then
                    for j = 1, Game.LOCATIONS_COUNT do
                        if #locations[j].opponentCards < Game.SLOTS_PER_LOCATION then
                            table.insert(validPlays, {card = card, location = j})
                        end
                    end
                end
            end
        else
            table.remove(validPlays, randomIndex)
        end
    end
    
    Player.submit(opponent)
end

local function revealCards()
    local playerTotalPower = 0
    local opponentTotalPower = 0
    
    for _, location in ipairs(locations) do
        playerTotalPower = playerTotalPower + location.playerPower
        opponentTotalPower = opponentTotalPower + location.opponentPower
    end
    
    local playerRevealsFirst = false
    if playerTotalPower > opponentTotalPower then
        playerRevealsFirst = true
    elseif playerTotalPower < opponentTotalPower then
        playerRevealsFirst = false
    else
        playerRevealsFirst = math.random() > 0.5
    end
    
    if playerRevealsFirst then
        for i, location in ipairs(locations) do
            for _, card in ipairs(location.playerCards) do
                if card.faceDown then
                    card.faceDown = false
                    if sounds.cardFlip then
                        love.audio.play(sounds.cardFlip)
                    end
                    executeCardEffect(card, player, i)
                end
            end
        end
        for i, location in ipairs(locations) do
            for _, card in ipairs(location.opponentCards) do
                if card.faceDown then
                    card.faceDown = false
                    if sounds.cardFlip then
                        love.audio.play(sounds.cardFlip)
                    end
                    executeCardEffect(card, opponent, i)
                end
            end
        end
    else
        for i, location in ipairs(locations) do
            for _, card in ipairs(location.opponentCards) do
                if card.faceDown then
                    card.faceDown = false
                    if sounds.cardFlip then
                        love.audio.play(sounds.cardFlip)
                    end
                    executeCardEffect(card, opponent, i)
                end
            end
        end
        for i, location in ipairs(locations) do
            for _, card in ipairs(location.playerCards) do
                if card.faceDown then
                    card.faceDown = false
                    
                    if sounds.cardFlip then
                        love.audio.play(sounds.cardFlip)
                    end
                    executeCardEffect(card, player, i)
                end
            end
        end
    end
    
    calculateLocationPowers()
    awardPoints()
    checkWinCondition()
end

local function nextTurn()
    if not gameOver then
        turn = turn + 1
        playerPlayHistory = {}
        Player.startTurn(player, turn)
        Player.startTurn(opponent, turn)
        
        Player.drawCard(player)
        Player.drawCard(opponent)
        
        Observer.notify("turnChanged", {
            turn = turn,
            player = player,
            opponent = opponent
        })
    end
end

function Game.initialize()
    turn = 1
    gameOver = false
    winner = nil
    playerPlayHistory = {}
    
    player = Player.new(createDeck())
    opponent = Player.new(createDeck())
    
    for _, location in ipairs(locations) do
        location.playerCards = {}
        location.opponentCards = {}
        location.playerPower = 0
        location.opponentPower = 0
    end
    
    for i = 1, Game.STARTING_HAND do
        Player.drawCard(player)
        Player.drawCard(opponent)
    end
    
    Player.drawCard(player)
    Player.drawCard(opponent)
    
    Observer.notify("gameInitialized", {
    player = player,
    opponent = opponent,
    turn = turn
    })
end

function Game.update()
    if Player.hasSubmitted(player) and Player.hasSubmitted(opponent) then
        revealCards()
        if not gameOver then
            love.timer.sleep(2)
            nextTurn()
        end
    elseif Player.hasSubmitted(player) and not Player.hasSubmitted(opponent) then
        aiTurn()
    end
end

function Game.playCard(card, playerData, locationIndex)
    if Player.getMana(playerData) >= card.cost then
        if playerData == player then
            table.insert(playerPlayHistory, {
                card = card,
                locationIndex = locationIndex,
                manaCost = card.cost
            })
        end
        
        Player.spendMana(playerData, card.cost)
        Player.removeFromHand(playerData, card)
        
        card.location = locationIndex
        card.faceDown = true
        if playerData == player then
            table.insert(locations[locationIndex].playerCards, card)
        else
            table.insert(locations[locationIndex].opponentCards, card)
        end
        
        Observer.notify("cardPlayed", {
            card = card,
            player = playerData,
            location = locationIndex
        })
        
        return true
    end
    return false
end

function Game.undoLastPlay()
    if #playerPlayHistory == 0 then
        return false
    end
    
    local lastPlay = playerPlayHistory[#playerPlayHistory]
    local card = lastPlay.card
    local locationIndex = lastPlay.locationIndex
    local manaCost = lastPlay.manaCost
    
    for i, locationCard in ipairs(locations[locationIndex].playerCards) do
        if locationCard == card then
            table.remove(locations[locationIndex].playerCards, i)
            break
        end
    end
    
    card.faceDown = false
    card.location = nil
    card.power = card.basePower
    
    table.insert(Player.getHand(player), card)
    
    player.mana = player.mana + manaCost
    
    table.remove(playerPlayHistory, #playerPlayHistory)
    
    return true
end

function Game.canPlayCardAtLocation(locationIndex)
    return #locations[locationIndex].playerCards < Game.SLOTS_PER_LOCATION
end

function Game.draw()
    love.graphics.setFont(headerFont)
    love.graphics.setColor(1, 0.8, 0)
    love.graphics.print("TITANS CLASH", 10, 50)
    love.graphics.setFont(normalFont)
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("Turn: " .. turn, 200, 50)
    love.graphics.print("Mana: " .. Player.getMana(player), 300, 50)
    love.graphics.print("Player Points: " .. Player.getPoints(player), 400, 50)
    love.graphics.print("Opponent Points: " .. Player.getPoints(opponent), 600, 50)
    love.graphics.print("Win Points: " .. Game.WIN_POINTS, 800, 50)
    
    love.graphics.setColor(0.7, 0.7, 0.7)
    love.graphics.print("Hand: " .. Player.getHandSize(player) .. "/" .. Game.HAND_SIZE, 900, 50)
  
    love.graphics.print("Deck: " .. Player.getDeckSize(player), 1000, 50)
    
    Game.drawLocations()
    
    Game.drawPlayerHand()
    
    Game.drawButtons()
end

function Game.drawLocations()
    local locationWidth = WINDOW_WIDTH / 3
    for i, location in ipairs(locations) do
        local x = (i - 1) * locationWidth
        
        love.graphics.setColor(0.2, 0.2, 0.3, 0.5)
        love.graphics.rectangle("fill", x + 10, 100, locationWidth - 20, 300)
        
        if cardFrames.banner_thick then
            love.graphics.setColor(1, 1, 1, 0.8)
            love.graphics.draw(cardFrames.banner_thick, x + 20, 105, 0,
                (locationWidth - 40) / cardFrames.banner_thick:getWidth(), 0.6)
        end
        
        love.graphics.setColor(1, 0.8, 0)
        love.graphics.printf(location.name, x, 115, locationWidth, "center")
        
        love.graphics.setColor(1, 1, 1)
        love.graphics.printf("Opponent (" .. location.opponentPower .. ")", x, 135, locationWidth, "center")
        
        if cardFrames.banner_thin then
            love.graphics.setColor(0.8, 0.4, 0.4, 0.7)
            love.graphics.draw(cardFrames.banner_thin, x + locationWidth/2 - 50, 130, 0, 100/cardFrames.banner_thin:getWidth(), 0.4)
        end
        
        for j, card in ipairs(location.opponentCards) do
            Game.drawCard(card, x + 20 + (j - 1) * 25, 150, true)
        end
        
        love.graphics.setColor(1, 1, 1)
        love.graphics.printf("Player (" .. location.playerPower .. ")", x, 250, locationWidth, "center")
        
        if cardFrames.banner_thin then
            love.graphics.setColor(0.4, 0.4, 0.8, 0.7)
            love.graphics.draw(cardFrames.banner_thin, x + locationWidth/2 - 50, 245, 0, 100/cardFrames.banner_thin:getWidth(), 0.4)
        end
        
        for j, card in ipairs(location.playerCards) do
            Game.drawCard(card, x + 20 + (j - 1) * 25, 270, false)
        end
    end
end


function Game.drawCard(card, x, y, isOpponent)
    love.graphics.setColor(1, 1, 1, 1)
    
    if card.faceDown then
        if faceDownCardImage then
            local steps = 5
            for i = 1, steps do
                local alpha = 0.8 - (i - 1) * 0.15
                local offset = (i - 1) * 2
                love.graphics.setColor(1, 1, 1, alpha)
                love.graphics.draw(
                    faceDownCardImage,
                    x + offset,
                    y + offset,
                    0,
                    (60 - offset * 2) / faceDownCardImage:getWidth(),
                    (80 - offset * 2) / faceDownCardImage:getHeight()
                )
            end
        else
            local steps = 8
            for i = 1, steps do
                local alpha = 0.8 - (i - 1) * 0.1
                local colorIntensity = 0.3 + (i - 1) * 0.05
                love.graphics.setColor(
                    0.2 + colorIntensity, 
                    0.1 + colorIntensity * 0.5, 
                    0.4 + colorIntensity, 
                    alpha
                )
                love.graphics.rectangle(
                    "fill", 
                    x + (i - 1) * 2, 
                    y + (i - 1) * 2, 
                    60 - (i - 1) * 4, 
                    80 - (i - 1) * 4
                )
            end
        end
        
        love.graphics.setColor(0.8, 0.6, 1, 0.8)
        love.graphics.rectangle("line", x, y, 60, 80)
        
        love.graphics.setColor(0.4, 0.4, 0.6, 0.3)
        for i = 1, 5 do
            love.graphics.line(x + 10, y + i * 12, x + 50, y + i * 12)
        end
        
    else
        if cardFrontImage then
            love.graphics.setColor(1, 1, 1, 1)
            love.graphics.draw(
                cardFrontImage,
                x,
                y,
                0,
                60 / cardFrontImage:getWidth(),
                80 / cardFrontImage:getHeight()
            )
            
            if isOpponent then
                love.graphics.setColor(0.8, 0.4, 0.4, 0.3)
            else
                love.graphics.setColor(0.4, 0.4, 0.8, 0.3)
            end
            love.graphics.rectangle("fill", x + 5, y + 5, 50, 70)
            
        else
            love.graphics.setColor(1, 1, 1, 1)
            
            if cardFrames and cardFrames.ornate then
                love.graphics.draw(
                    cardFrames.ornate,
                    x - 5,
                    y - 5,
                    0,
                    70 / cardFrames.ornate:getWidth(),
                    90 / cardFrames.ornate:getHeight()
                )
            end
            
            if isOpponent then
                love.graphics.setColor(0.8, 0.4, 0.4, 0.9)
            else
                love.graphics.setColor(0.4, 0.4, 0.8, 0.9)
            end
            love.graphics.rectangle("fill", x + 5, y + 5, 50, 70)
        end
        
        love.graphics.setColor(1, 1, 1, 1)
        love.graphics.setFont(cardFont or love.graphics.getFont())
        
        love.graphics.printf(card.name:sub(1, 8), x + 2, y + 8, 56, "center")
        
        love.graphics.printf(card.cost .. "/" .. card.power, x + 2, y + 55, 56, "center")
        
        if card.power >= 5 and cardFrames and cardFrames.crown then
            love.graphics.setColor(1, 1, 1, 0.8)
            love.graphics.draw(
                cardFrames.crown, 
                x + 45, 
                y - 10, 
                0,
                0.3,
                0.3
            )
        end
    end
    
    love.graphics.setColor(1, 1, 1, 1)
end

function Game.drawPlayerHand()
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("Hand:", 10, 500)
    love.graphics.setFont(normalFont or love.graphics.getFont())
    love.graphics.print("Right Click to inspect the card:", 10, 470)
    
    for i, card in ipairs(Player.getHand(player)) do
        local cardX = 10 + (i - 1) * 110
        local cardY = 520
        
        love.graphics.setColor(1, 1, 1, 1)
        if cardFrames.banner_thick then
            love.graphics.draw(cardFrames.banner_thick, cardX - 10, cardY - 10, 0,
                (CARD_WIDTH + 20) / cardFrames.banner_thick:getWidth(),
                (CARD_HEIGHT + 20) / cardFrames.banner_thick:getHeight())
        end
        
        if card.cost <= Player.getMana(player) then
            love.graphics.setColor(0.4, 0.8, 0.4, 0.9)
        else
            love.graphics.setColor(0.8, 0.4, 0.4, 0.9)
        end
        love.graphics.rectangle("fill", cardX + 5, cardY + 5, CARD_WIDTH - 10, CARD_HEIGHT - 10)
        
        love.graphics.setColor(1, 1, 1)
        love.graphics.rectangle("line", cardX, cardY, CARD_WIDTH, CARD_HEIGHT)
        
        love.graphics.setColor(0, 0, 0)
        love.graphics.setFont(cardFont or love.graphics.getFont())
        love.graphics.printf(card.name, cardX + 5, cardY + 5, CARD_WIDTH - 10, "center")
        love.graphics.printf("Cost: " .. card.cost, cardX + 5, cardY + 35, CARD_WIDTH - 10, "center")
        love.graphics.printf("Power: " .. card.power, cardX + 5, cardY + 45, CARD_WIDTH - 10, "center")
        love.graphics.printf(card.text:sub(1, 50), cardX + 5, cardY + 70, CARD_WIDTH - 10, "center")
    end
end

function Game.drawButtons()
    if not Player.hasSubmitted(player) and #playerPlayHistory > 0 then
        love.graphics.setColor(0.8, 0.6, 0.2)
        love.graphics.rectangle("fill", WINDOW_WIDTH - 240, 10, 100, 30)
        love.graphics.setColor(0, 0, 0)
        love.graphics.printf("UNDO (U)", WINDOW_WIDTH - 240, 20, 100, "center")
    elseif not Player.hasSubmitted(player) then
        love.graphics.setColor(0.5, 0.5, 0.5)
        love.graphics.rectangle("fill", WINDOW_WIDTH - 240, 10, 100, 30)
        love.graphics.setColor(0.3, 0.3, 0.3)
        love.graphics.printf("UNDO (U)", WINDOW_WIDTH - 240, 20, 100, "center")
    end
    
    if not Player.hasSubmitted(player) then
        love.graphics.setColor(0.8, 0.8, 0.2)
        love.graphics.rectangle("fill", WINDOW_WIDTH - 120, 10, 100, 30)
        love.graphics.setColor(0, 0, 0)
        love.graphics.printf("SUBMIT", WINDOW_WIDTH - 120, 20, 100, "center")
    else
        love.graphics.setColor(0.5, 0.5, 0.5)
        love.graphics.rectangle("fill", WINDOW_WIDTH - 120, 10, 100, 30)
        love.graphics.setColor(1, 1, 1)
        love.graphics.printf("WAITING", WINDOW_WIDTH - 120, 20, 100, "center")
    end
end

function Game.getPlayer() return player end
function Game.getOpponent() return opponent end
function Game.getWinner() return winner end
function Game.getTurn() return turn end
function Game.getPlayHistoryCount() return #playerPlayHistory end

function Game.getLocations()
    return locations
end

function Game.getCardAtLocationPosition(x, y)
    local locationWidth = WINDOW_WIDTH / 3
    
    for i, location in ipairs(locations) do
        local locX = (i - 1) * locationWidth
        
        for j, card in ipairs(location.opponentCards) do
            local cardX = locX + 20 + (j - 1) * 25
            local cardY = 150
            
            if x >= cardX and x <= cardX + 60 and y >= cardY and y <= cardY + 80 then
                return card
            end
        end
        
        for j, card in ipairs(location.playerCards) do
            local cardX = locX + 20 + (j - 1) * 25
            local cardY = 270
            
            if x >= cardX and x <= cardX + 60 and y >= cardY and y <= cardY + 80 then
                return card
            end
        end
    end
    
    return nil
end

return Game