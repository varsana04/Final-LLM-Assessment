Observer = {}

local observers = {}

function Observer.addObserver(event, callback)
    if not observers[event] then
        observers[event] = {}
    end
    table.insert(observers[event], callback)
end

function Observer.removeObserver(event, callback)
    if observers[event] then
        for i, obs in ipairs(observers[event]) do
            if obs == callback then
                table.remove(observers[event], i)
                break
            end
        end
    end
end

function Observer.notify(event, data)
    if observers[event] then
        for _, callback in ipairs(observers[event]) do
            callback(data)
        end
    end
end

function Observer.clearObservers(event)
    if event then
        observers[event] = {}
    else
        observers = {}
    end
end

return Observer