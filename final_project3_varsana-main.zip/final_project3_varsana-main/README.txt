One of the core patterns used in this project is the Observer Pattern, which is implemented through the Observer module. This pattern enables different parts of the game to communicate through events without being tightly coupled. For instance, when a card is played, mana is spent, or the game state changes, the function is called to broadcast that event. This decoupling is useful for maintaining modularity and scalability, allowing the game to remain flexible. 

The State Pattern is another important pattern I used, especially for managing different phases of the game. I implemented this by defining a GAME_STATE table with states like "title", "playing", and "game_over". Each of these states controls specific behaviors for input handling, rendering, and logic. This separation ensures that each phase of the game has its own responsibilities which make the transitions predictable and reduces bugs caused by conflicting logic.

The Game Loop Pattern was used through LÖVE2D’s built-in love.update(dt) and love.draw() functions. This pattern is needed to maintain a consistent loop of game logic updates and rendering. By separating update logic from rendering, it allows smooth animations and real-time responsiveness while ensuring that the game runs consistently across different systems. 

The code also uses Event Queue Pattern by using LÖVE2D’s input event system. Functions like love.mousepressed and love.keypressed process inputs in the order they are received, which ensures smooth and sequential handling of player interactions. This keeps input handling clean and prevents logic conflicts during gameplay.

The Flyweight Pattern is partially implemented in the way card data and assets are managed. Card images and template data are loaded once and reused across all instances, which minimizes the memory usage and speeeds up rendering. Each card instance only tracks position or power, which improves efficiency when managing many similar objects.

I also partially used the command pattern for the undo functionality. Player actions like playing a card or spending mana are stored in a history table, which enables the reversal of those actions by restoring previous states. 



Assets: 
Background Image: 
https://www.google.com/search?sca_esv=a89d269aec3ce157&q=background+wallpaper+mystic&udm=2&fbs=AIIjpHxU7SXXniUZfeShr2fp4giZ1Y6MJ25_tmWITc7uy4KIeioyp3OhN11EY0n5qfq-zENwnGygERInUV_0g0XKeHGJRAdFPaX_SSIJt7xYUfpm-75lA8Uar42yNWdqGuJlUAnl4VoyIc9TvIZo00AnzLuo73CKalUXQ8cWgmottQs4BXh0bU9aRqLPpzWejdabGFvk-MuP83mUuK41Ro6dMLX7Czip9A&sa=X&ved=2ahUKEwi20evB5NaNAxWjFzQIHbUrF4IQtKgLegQIDhAB&biw=1283&bih=786&dpr=2#vhid=ir-7sJ5cxk5oHM&vssid=mosaic


Card Frame: 
https://opengameart.org/users/cethiel
https://www.patreon.com/cethiel

Sounds: 
Draw SFX: https://pixabay.com/sound-effects/flipcard-91468/
Win SFX: https://pixabay.com/sound-effects/success-1-6297/





